<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Upload bestanden hier';
$lang['upload-drop-area'] = 'Sleep de bestanden hier naar toe om ze up te loaden';
$lang['upload-cancel'] = 'Annuleren';
$lang['upload-failed'] = 'Mislukt';

$lang['loading'] = 'Laden, wacht alstublieft.. ';
$lang['deleting'] = 'Verwijderen, wacht alstublieft.. ';
$lang['saving_title'] = 'Opslaan titel.. ';

$lang['list_delete'] = 'Verwijderen';
$lang['alert_delete'] = 'Weet je zeker dat je deze afbeelding wilt verwijderen? ';

/* End of file dutch.php */
/* Location: ./assets/image_crud/languages/dutch.php */