<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Datei-Upload hier';
$lang['upload-drop-area'] = 'Datei hier ablegen';
$lang['upload-cancel'] = 'Abbrechen';
$lang['upload-failed'] = 'Fehlgeschlagen';

$lang['loading'] = 'Upload läuft, bitte warten...';
$lang['deleting'] = 'Datei wird gelöscht, bitte warten...';
$lang['saving_title'] = 'Titel wird gespeichert...';

$lang['list_delete'] = 'Löschen';
$lang['alert_delete'] = 'Diese Bild wirklich löschen?';

/* End of file german.php */
/* Location: ./assets/image_crud/languages/german.php */
