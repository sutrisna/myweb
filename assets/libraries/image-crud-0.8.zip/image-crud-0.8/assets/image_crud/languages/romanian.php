<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Încărca fișiere';
$lang['upload-drop-area'] = 'Trageți fișierele aici pentru a încărca';
$lang['upload-cancel'] = 'Anuleaza';
$lang['upload-failed'] = 'Încărcare eșuată';

$lang['loading'] = 'Se încarcă... Vă rugăm să așteptați...';
$lang['deleting'] = 'Se Şterge... Vă rugăm să așteptați...';
$lang['saving_title'] = 'Salvare denumire...';

$lang['list_delete'] = 'Ştergeţi';
$lang['alert_delete'] = 'Sunteţi sigur că doriţi să ştergeţi această imagine?';

/* End of file romanian.php */
/* Location: ./assets/image_crud/languages/romanian.php */
